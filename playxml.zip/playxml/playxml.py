import time
import signal
import pprint
import xml.etree.ElementTree as ET
import argparse

import rtmidi2 as rm


DEFAULT_DEVICE = 0


def keyboardInterruptHandler(signal, frame):
    print("KeyboardInterrupt (ID: {}) has been caught. Cleaning up...".format(signal))
    exit(0)

signal.signal(signal.SIGINT, keyboardInterruptHandler)

#############################
# ARGUMENTS

out = rm.MidiOut()

midi_outs = rm.get_out_ports()

parser = argparse.ArgumentParser(
                    prog='PlayXML',
                    description="""Play Music XML files on the following midi device:""",
                    epilog='Clément Borel',
                    formatter_class=argparse.RawTextHelpFormatter)

parser.add_argument('xmlfilename', help="The actual xml file to play")  

parser.add_argument('--bpm', type=int, help="BPM")

parser.add_argument('-v', '--verbose', action="store_true", help="Verbose Mode")
parser.add_argument('-np', '--noplay', action="store_true", help="Wait enter for play")

if len(midi_outs) == 0:
    exit("Aborted, No midi device found !")

parser.add_argument('--midiout', type=int, 
                    default=DEFAULT_DEVICE,
                    choices=[ i for i, o in enumerate(midi_outs) ], 
                    help="Output Midi Device Number, Default is 0 (%s)\n\n%s" % (midi_outs[0], 
                            "\n".join([ "%s: %s" % (i, o) for i, o in enumerate(midi_outs) ])))  

args = parser.parse_args()

########################
# XML STUFF

notes2midi = { rm.midi2note(i): i for i in range(-255, 255) }

t = time.perf_counter()

def nanosleep(s):
    ''' high precision sleep timer '''
    global t
    first = True
    while time.perf_counter() - t < s:
        first = False
        continue
    t2 = time.perf_counter()
    if first:
        print("WARNING: timer drift %ss" % s)
    t = t2

class Note():

    def __init__(self, note, duration = 4, velo=127, offset=0, channel=1) -> None:
        self.note = note
        self.offset = offset
        self.duration = duration
        self.velo = velo
        self.channel = channel
        
        # easy notation support
        if isinstance(note, str):
            self.note = notes2midi[note]

        self.hnote = rm.midi2note(self.note)

        if duration < 1:
            self.duration = int(duration * 16)
        if offset < 1:
            self.offset = int(offset * 16)

    def play(self, i):
        if i == self.offset:
            if args.verbose:
                print("%s note %s channel %s duration %s" % ( i, self.note, self.channel, self.duration) )
            out.send_noteon(self.channel, self.note, self.velo)
        elif i == self.duration + self.offset:
            if args.verbose:
                print("%s note off %s channel %s" % ( i, self.note, self.channel) )
            out.send_noteoff(self.channel, self.note)

class Sheet():

    def __init__(self) -> None:
        self.notes = {}
        self.beat_time = 4
        self.beat_type = 4
        self.measures = 0
        self.bpm = None
        self.beat_duration = 0
        self.instruments = {}

    def duration(self):
        return self.measures * self.beat_time * ( 60 / self.bpm )
    
    def pause(self, duration):
        nanosleep( self.beat_duration * duration )

    def note(self, measure, note):
        if args.verbose:
            print("%s add %s / %s" % (measure, note.hnote, note.duration))
        note.offset = measure
        self.__update(measure+note.duration)
        notes = self.notes.get(measure, [])
        self.notes.update( { measure: notes + [ note ] } )
        notes = self.notes.get(measure+note.duration, [])
        self.notes.update( { measure+note.duration: notes + [ note ] } )

    def __update(self, offset):
        for i in range(offset+64):
            self.notes.update( { i: self.notes.get(i, []) } )
    
    def play(self):
        global t
        self.beat_duration = ( 60 / self.bpm )
        t = time.perf_counter()
        for b, notes in self.notes.items():
            if args.verbose:
                print(b)
            for note in notes:
                note.play(b)
            self.pause(1)


#for i in range(-24, 92):
#    print("note %s is %s" % (i, rm.midi2note(i)))

def parseMXML2Score(mxmlfile):
    tree = ET.parse(mxmlfile)
    root = tree.getroot()

    score = Sheet()

    for part in root.find('./part-list').findall('score-part'):
        score.instruments[part.attrib["id"]] = { 
            "name": part.find('./part-name').text,
            "channel": int(part.find('./midi-instrument/midi-channel').text),
        }
    
    for part in root.findall('./part'):
        midi_channel = score.instruments[part.attrib["id"]]["channel"]
        length = 0
        for measure in part.findall('./measure'):
            length += 1

            snd = measure.findall('./sound')
            if len(snd) > 0:
                score.bpm = int(snd[0].attrib['tempo'])

            division = measure.find('./attributes/divisions')
            if division is not None:
                division = 1 / int(measure.find('./attributes/divisions').text)
            else:
                division = 1
            m = int(measure.attrib["number"])-1

            if args.verbose:
                print("measure offset %s" % m)

            offset = m*score.beat_time
            for note in measure.findall('./note'):
                alt = note.find('./pitch/alter')
                if alt is not None and int(alt.text) == 1:
                    alt = "#"
                    
                duration = score.beat_time
                if note.find('./duration') is not None:
                    duration = int(note.find('./duration').text)
                
                if note.find('./pitch') is not None: 
                    n = Note("".join([ note.find('./pitch/step').text, 
                                        alt or "",
                                        note.find('./pitch/octave').text ]
                                    ),
                                    duration=duration,
                                    channel=midi_channel)
                    score.note( offset, n )
                    if args.verbose:
                        print("offset %s" % offset)
                offset += duration
        
        if score.measures < length:
            score.measures = length
        
    return score

#
# MAIN
#
def main():

    out.open_port(args.midiout)

    print("Will play on %s" % midi_outs[args.midiout])

    score = parseMXML2Score(args.xmlfilename)

    print("Loaded %s" % args.xmlfilename)

    if args.bpm:
        print("force bpm to %s BPM" % args.bpm)
        score.bpm = args.bpm

    print("Instruments:")
    for k, v in score.instruments.items():
        print("\t(%s) %s channel %s" % (k, v["name"], v["channel"]))
        
    print("%s BPM" % score.bpm)
    print("%s measures" % score.measures)
    print("duration %s s" % score.duration())

    if args.noplay:
        input("press enter to play")

    score.play()

if __name__ == "__main__":
    main()